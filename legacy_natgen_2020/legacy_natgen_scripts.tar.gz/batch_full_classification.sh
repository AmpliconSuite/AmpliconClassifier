#!/bin/bash

# Master script to run complete amplicon analysis
# Usage: ./run_complete_analysis.sh <input_file> [options]

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

INPUT_FILE=$1
GENOME_BUILD="GRCh38"
EXCLUDE_BED=""
RUN_CLASSIFICATION=true
RUN_BFB=true
OUTPUT_DIR="analysis_results"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -g|--genome)
            GENOME_BUILD="$2"
            shift 2
            ;;
        -e|--exclude)
            EXCLUDE_BED="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --classification-only)
            RUN_BFB=false
            shift
            ;;
        --bfb-only)
            RUN_CLASSIFICATION=false
            shift
            ;;
        -h|--help)
            echo "Usage: $0 <input_file> [options]"
            echo ""
            echo "Options:"
            echo "  -g, --genome BUILD      Genome build (hg19, GRCh37, GRCh38) [default: GRCh38]"
            echo "  -e, --exclude BED       BED file with regions to exclude"
            echo "  -o, --output DIR        Output directory [default: analysis_results]"
            echo "  --classification-only   Run only amplicon classification"
            echo "  --bfb-only              Run only BFB analysis"
            echo "  -h, --help              Show this help message"
            echo ""
            echo "Example:"
            echo "  $0 AC_GRCh38.input -g GRCh38 -e exclude.bed -o results"
            exit 0
            ;;
        *)
            if [ -z "$INPUT_FILE" ]; then
                INPUT_FILE="$1"
            fi
            shift
            ;;
    esac
done

if [ -z "$INPUT_FILE" ]; then
    echo "Error: Input file is required"
    echo "Use -h or --help for usage information"
    exit 1
fi

if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: Input file not found: $INPUT_FILE"
    exit 1
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Setup log files - clear them at start of each run
CLASSIFICATION_LOG="$OUTPUT_DIR/classification.log"
BFB_LOG="$OUTPUT_DIR/bfb.log"
> "$CLASSIFICATION_LOG"  # Clear classification log
> "$BFB_LOG"             # Clear BFB log

echo "=== Amplicon Analysis Pipeline ==="
echo "Input file: $INPUT_FILE"
echo "Genome build: $GENOME_BUILD"
echo "Output directory: $OUTPUT_DIR"
echo "Exclude BED: ${EXCLUDE_BED:-"None"}"
echo "Run classification: $RUN_CLASSIFICATION"
echo "Run BFB analysis: $RUN_BFB"
echo ""

# Generate statistics about the input
echo "=== Input Statistics ==="
TOTAL_AMPLICONS=$(wc -l < "$INPUT_FILE")
UNIQUE_SAMPLES=$(awk -F'\t' '{print $1}' "$INPUT_FILE" | sort | uniq | wc -l)
echo "Total amplicons: $TOTAL_AMPLICONS"
echo "Unique samples: $UNIQUE_SAMPLES"

# Show sample distribution
echo ""
echo "Amplicons per sample (top 10):"
awk -F'\t' '{print $1}' "$INPUT_FILE" | sort | uniq -c | sort -nr | head -10 | awk '{printf "  %-15s %d\n", $2, $1}'
echo ""

# Run amplicon classification if requested
if [ "$RUN_CLASSIFICATION" = true ]; then
    echo "=== Running Amplicon Classification ==="
    CLASSIFICATION_DIR="$OUTPUT_DIR/classification"
    mkdir -p "$CLASSIFICATION_DIR"

    # Extract unique sample-directory combinations
    TEMP_SAMPLES=$(mktemp)
    awk -F'\t' '{
        split($2, path_parts, "/");
        n = length(path_parts);
        dir = "";
        for(i=1; i<n; i++) {
            dir = dir path_parts[i] "/";
        }
        gsub(/\/$/, "", dir);

        # Extract base sample name from the first column (sample name)
        # Remove _amplicon[number] suffix to get base sample name
        sample_id = $1;
        gsub(/_amplicon[0-9]+$/, "", sample_id);

        print sample_id "\t" dir;
    }' "$INPUT_FILE" | sort | uniq > "$TEMP_SAMPLES"

    counter=0
    total=$(wc -l < "$TEMP_SAMPLES")
    failed=0

    while IFS=$'\t' read -r SAMPLE_ID AMPLICON_DIR; do
        ((counter++))
        printf "[$counter/$total] Processing $SAMPLE_ID... "

        OUTPUT_FILE="$CLASSIFICATION_DIR/${SAMPLE_ID}_amplicon_classification.txt"

        if "$SCRIPT_DIR/classify_amplicon.py" -d "$AMPLICON_DIR" -p "$SAMPLE_ID" -o "$OUTPUT_FILE" >> "$CLASSIFICATION_LOG" 2>&1; then
            echo "done"
        else
            echo "failed"
            ((failed++))
        fi

    done < "$TEMP_SAMPLES"

    rm "$TEMP_SAMPLES"
    echo "Classification completed: $((total-failed))/$total successful"
    echo ""
fi

# Run BFB analysis if requested
if [ "$RUN_BFB" = true ]; then
    echo "=== Running BFB Analysis ==="

    # Create graph list table
    GRAPH_LIST_TABLE="$OUTPUT_DIR/graph_list_table.txt"
    awk -F'\t' '{
        split($3, path_parts, "/");
        filename = path_parts[length(path_parts)];
        gsub(/_graph\.txt$/, "", filename);
        print filename "\t" $3;
    }' "$INPUT_FILE" > "$GRAPH_LIST_TABLE"

    echo "Created graph list table: $GRAPH_LIST_TABLE"

    # Prepare BFB command
    BFB_CMD="$SCRIPT_DIR/bfb_foldback_detection.py --ref $GENOME_BUILD --AA_graph_list $GRAPH_LIST_TABLE -o $OUTPUT_DIR/bfb_results"

    if [ -n "$EXCLUDE_BED" ] && [ -f "$EXCLUDE_BED" ]; then
        BFB_CMD="$BFB_CMD --exclude $EXCLUDE_BED"
    fi

    echo "Running: $BFB_CMD"

    if eval "$BFB_CMD" >> "$BFB_LOG" 2>&1; then
        echo "BFB analysis completed successfully"
    else
        echo "BFB analysis failed"
    fi
    echo ""
fi

echo "=== Analysis Complete ==="
echo "Results saved in: $OUTPUT_DIR"
echo ""
echo "Output structure:"
if [ "$RUN_CLASSIFICATION" = true ]; then
    echo "  classification/         - Amplicon classification results"
    echo "  classification.log      - Classification process log"
fi
if [ "$RUN_BFB" = true ]; then
    echo "  bfb_results*            - BFB analysis results"
    echo "  bfb.log                 - BFB analysis log"
    echo "  graph_list_table.txt    - Graph list table for BFB"
fi